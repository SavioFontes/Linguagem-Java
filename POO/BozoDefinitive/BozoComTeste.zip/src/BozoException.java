
public class BozoException extends Exception{
	public BozoException(String message) {
		super(message);
	}
}
